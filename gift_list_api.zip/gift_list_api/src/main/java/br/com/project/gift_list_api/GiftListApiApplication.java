package br.com.project.gift_list_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiftListApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GiftListApiApplication.class, args);
	}

}
